package com.example.demo.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.Entity.User;
import com.example.demo.UserService.UserService;
import com.example.demo.UserService.MentorService;
import com.example.demo.dto.LoginRequest;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("*")
public class AuthController {
    private final UserService userService;
    private final MentorService mentorService;

    public AuthController(UserService userService, MentorService mentorService) {
        this.userService = userService;
        this.mentorService = mentorService;
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        return ResponseEntity.ok(userService.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
        boolean isAuthenticated = userService.loginUser(loginRequest.getEmail(), loginRequest.getPassword());
        
        if (isAuthenticated) {
            return ResponseEntity.ok("User Login Successful");
        } else {
            return ResponseEntity.status(401).body("Invalid Credentials");
        }
    }

    @CrossOrigin("*")
    @PostMapping("/mentorlogin")
    public ResponseEntity<String> mentorLogin(@RequestBody LoginRequest loginRequest) {
        boolean isAuthenticated = mentorService.loginMentor(loginRequest.getEmail(), loginRequest.getPassword());
    
        if (isAuthenticated) {
            return ResponseEntity.ok("Mentor Login Successful");
        } else {
            return ResponseEntity.status(401).body("Invalid Credentials");
        }
    }
}
