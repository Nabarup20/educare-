package com.example.demo.UserService;
import com.example.demo.Entity.Admin;
import com.example.demo.Repository.AdminRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdminService {
    private final AdminRepository adminRepository;

    private static final String DEFAULT_ADMIN_EMAIL = "admin@eduskill.com";
    private static final String DEFAULT_ADMIN_PASSWORD = "Admin@123";

    public AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    @PostConstruct
    public void createDefaultAdmin() {
        Optional<Admin> adminOptional = adminRepository.findByEmail(DEFAULT_ADMIN_EMAIL);
        if (adminOptional.isEmpty()) {
            Admin admin = new Admin(DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD);
            adminRepository.save(admin);
            System.out.println("✅ Default admin created.");
        } else {
            System.out.println("✅ Admin already exists.");
        }
    }

    public boolean loginAdmin(String email, String password) {
        Optional<Admin> adminOptional = adminRepository.findByEmail(email);
        return adminOptional.map(admin -> admin.getPassword().equals(password)).orElse(false);
    }
}
