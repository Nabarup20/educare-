package com.example.demo.UserService;

import org.springframework.stereotype.Service;
import com.example.demo.Entity.Mentor;
import com.example.demo.Repository.MentorRepository;
import java.util.Optional;

@Service
public class MentorService {
    private final MentorRepository mentorRepository;

    public MentorService(MentorRepository mentorRepository) {
        this.mentorRepository = mentorRepository;
    }

    public boolean loginMentor(String email, String password) {
        Optional<Mentor> mentorOptional = mentorRepository.findByEmail(email);
        if (mentorOptional.isPresent()) {
            Mentor mentor = mentorOptional.get();
            return mentor.getPassword().equals(password);  // ⚠ In production, use hashing!
        }
        return false;
    }
}
