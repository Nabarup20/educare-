document.addEventListener("DOMContentLoaded", function () {
    // Simulate fetching user count
    fetch("http://localhost:8080/api/admin/stats")
        .then(response => response.json())
        .then(data => {
            document.getElementById("userCount").innerText = data.totalUsers;
            document.getElementById("courseCount").innerText = data.totalCourses;
        })
        .catch(error => {
            console.error("Error fetching stats:", error);
            document.getElementById("userCount").innerText = "N/A";
            document.getElementById("courseCount").innerText = "N/A";
        });

    // Logout functionality
    document.getElementById("logout").addEventListener("click", function () {
        localStorage.removeItem("adminToken"); // Clear stored session
        window.location.href = "admin-login.html"; // Redirect to login page
    });
});
