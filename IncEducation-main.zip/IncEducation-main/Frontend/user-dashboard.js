document.addEventListener('DOMContentLoaded', () => {
    // Animate overall progress circle
    const progressCircle = document.querySelector('.progress-circle');
    const progressPercentage = parseInt(progressCircle.getAttribute('data-progress'));
    progressCircle.style.background = `conic-gradient(#673ad9 ${progressPercentage * 3.6}deg, #e0e0e0 0deg)`;

    // Animate individual course progress bars
    const progressBars = document.querySelectorAll('.progress-bar');
    progressBars.forEach(bar => {
        const progress = bar.getAttribute('data-progress');
        const progressElement = bar.querySelector('.progress');
        progressElement.style.width = `${progress}%`;
    });

    // Add hover effect to course cards
    const courseCards = document.querySelectorAll('.course-card');
    courseCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-10px)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });
});