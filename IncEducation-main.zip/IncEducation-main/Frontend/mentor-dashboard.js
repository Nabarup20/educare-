document.addEventListener('DOMContentLoaded', function() {
    // Main tabs functionality
    const tabTriggers = document.querySelectorAll('.tab-trigger');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabTriggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            // Remove active class from all triggers and contents
            tabTriggers.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked trigger and corresponding content
            trigger.classList.add('active');
            const tabId = trigger.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Section tabs functionality
    const sectionTabTriggers = document.querySelectorAll('.section-tab-trigger');
    const sectionTabContents = document.querySelectorAll('.section-tab-content');
    
    sectionTabTriggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            // Remove active class from all section triggers and contents
            sectionTabTriggers.forEach(t => t.classList.remove('active'));
            sectionTabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked trigger and corresponding content
            trigger.classList.add('active');
            const sectionId = trigger.getAttribute('data-section');
            document.getElementById(`${sectionId}-section`).classList.add('active');
        });
    });
    
    // Form submission
    const courseForm = document.getElementById('courseForm');
    
    courseForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = {
            topic: document.getElementById('topic').value,
            description: document.getElementById('description').value,
            price: document.getElementById('price').value,
            videoLink: document.getElementById('videoLink').value,
            pdfFile: document.getElementById('pdfFile').files[0] ? document.getElementById('pdfFile').files[0].name : null,
            schedule: document.getElementById('schedule').value
        };
        
        // Log form data (in a real application, you would send this to your server/database)
        console.log('Form submitted:', formData);
        
        // Show success message
        alert('Course added successfully!');
        
        // Reset form
        courseForm.reset();
    });
});